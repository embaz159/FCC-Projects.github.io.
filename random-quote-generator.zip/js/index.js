$(document).ready(function() {
  var randomQuote;
  var randomNum;
  var author;
  getQuote();
  function getQuote() {
    var quotes = [
      "You can be free. You can live and work anywhere in the world. You can be independent from routine and not answer to anybody.",
      "I believe in analysis and not forecasting.",
      "The secret to being successful from a trading perspective is to have an indefatigable and an undying and unquenchable thirst for information and knowledge.",
      "What seems too high and risky to the majority generally goes higher and what seems low and cheap generally goes lower.",
      "You don't need to be a rocket scientist. Investing is not a game where the guy with the 160 IQ beats the guy with 130 IQ.",
      "Markets are constantly in a state of uncertainty and flux and money is made by discounting the obvious and betting on the unexpected.",
      "Throughout my financial career, I have continually witnessed examples of other people that I have known being ruined by a failure to respect risk. If you don’t take a hard look at risk, it will take you.",
      "If you personalize losses, you can't trade.",
      "The four most dangerous words in investing are: This time it's different.",
      "Markets can remain irrational longer than you can remain solvent.",
      "Win or lose, everybody gets what they want out of the market. Some people seem to like to lose, so they win by losing money.",
      "A peak performance trader is totally committed to being the best and doing whatever it takes to be the best. He feels totally responsible for whatever happens and thus can learn from mistakes. These people typically have a working business plan for trading because they treat trading as a business.",
      "A lot of people get so enmeshed in the markets that they lose their perspective. Working longer does not necessarily equate with working smarter. In fact, sometimes is the other way around.",
      "Every trader has strengths and weakness. Some are good holders of winners, but may hold their losers a little too long. Others may cut their winners a little short, but are quick to take their losses. As long as you stick to your own style, you get the good and bad in your own approach.",
      "Money is made by sitting, not trading.",
      "Letting losses run is the most serious mistake made by most investors.",
      "That cotton trade was almost the deal breaker for me. It was at that point that I said, ‘Mr. Stupid, why risk everything on one trade? Why not make your life a pursuit of happiness rather than pain?",
      "Frankly, I don’t see markets; I see risks, rewards, and money.",
      "I always define my risk, and I don’t have to worry about it.",
      "The goal of a successful trader is to make the best trades. Money is secondary.",
      "In this business if you’re good, you’re right six times out of ten. You’re never going to be right nine times out of ten.",
      "It takes 20 years to build a reputation and 5 minutes to ruin it. If you think about that, you’ll do things differently.",
      "If you personalize losses, you can’t trade.",
      "Don’t focus on making money, focus on protecting what you have."
    ];

    var author1 = [
      "-Alexander Elder",
      "-Nicolas Darvas",
      "-Paul Tudor Jones",
      "-William O'Neil",
      "-Warren Buffet",
      "-George Soros",
      "-Larry Hite",
      "-Bruce Kovner",
      "-Sir John Templeton",
      "-John Maynard Keynes",
      "-Ed Seykota",
      "-Van K. Tharp",
      "-Martin Schwartz",
      "-Michael Marcus",
      "-Jesse Livermore",
      "-William O’Neil",
      "-Paul Tudor Jones",
      "-Larry Hite",
      "-Tony Saliba",
      "Alexander Elder",
      "-Peter Lynch",
      "-Warren Buffett",
      "-Bruce Kovner",
      "-Paul Tudor Jones"
    ];

    randomNum = Math.floor(Math.random() * quotes.length);
    randomQuote = quotes[randomNum];
    author = author1[randomNum];
    $(".quote").text(randomQuote);
    $(".author").text(author);
  }

  $("#tweetButton").on("click", function() {
    window.open(
      "https://twitter.com/intent/tweet?text=" + randomQuote + " " + author
    );
  });

  $("#quoteButton").on("click", function() {
    getQuote();
  });
});