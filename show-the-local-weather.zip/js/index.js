$(document).ready(function() {
  var lat;
  var long;
  $.getJSON("https://freegeoip.net/json/", function(data2) {
    lat = data2.latitude;
    long = data2.longitude;
    console.log(lat);
    console.log(long);
    //created an api with the user's geolocation
    var api =
      "https://api.openweathermap.org/data/2.5/weather?lat=" +
      lat +
      "&lon=" +
      long +
      "&appid=f6d46a2c3410f20f5fe104399ab8d503";
    console.log(api);

    $.getJSON(api, function(data) {
      var fTemp;
      var cTemp;
      var kTemp;
      var tempSwap = true;
      //JSON call for Open Weather API
      var weatherType = data.weather[0].description;
      kTemp = data.main.temp;
      var windSpeed = data.wind.speed;
      //City name
      var city = data.name;
      //Country name
      var country = data.sys.country;
      //Temperture in Kelvin
      fTemp = (kTemp * (9 / 5) - 459.67).toFixed(1);
      //Temp in F
      cTemp = (kTemp - 273).toFixed(1);
      console.log(city);
      $("#city").html(city);
      $("#country").html(country);
      $("#weatherType").html(weatherType);
      $("#fTemp").html(fTemp + " &#8457;");
      $("#fTemp").click(function() {
        if (tempSwap === false) {
          $("#fTemp").html(fTemp + " &#8457;");
          tempSwap = true;
        } else {
          $("#fTemp").html(cTemp + " &#8451;");
          tempSwap = false;
        }
      });
      windSpeed = (2.237 * windSpeed).toFixed(1);
      $("#windSpeed").html(windSpeed + " mph");
      if (fTemp > 70) {
        $("body").css(
          "background-image",
          "url(https://images.unsplash.com/uploads/14121010130570e22bcdf/e1730efe?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=ef988268a1a4d5acc2a6b0f53275c25a&auto=format&fit=crop&w=1350&q=80)"
        );
      } else if (fTemp > 60) {
        $("body").css(
          "background-image",
          "url(https://images.unsplash.com/photo-1418835817666-45fa43c32666?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=7b260793b2dc2daa65f935f9fde989d5&auto=format&fit=crop&w=1350&q=80)"
        );
      } else if (fTemp > 40) {
        $("body").css(
          "background-image",
          "url(https://images.unsplash.com/photo-1517309230475-6736d926b979?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=c77078ab04836355996d36d507f80ba3&auto=format&fit=crop&w=1350&q=80)"
        );
      } else if (fTemp <= 40) {
        $("body").css(
          "background-image",
          "url(https://images.unsplash.com/photo-1519293515161-2b9fd3c9a4dc?ixlib=rb-0.3.5&s=5084b54e63cbe97c603fee868d6db0d6&auto=format&fit=crop&w=1350&q=80)"
        );
      }
    });
  });
  //API URL with geolocation
});